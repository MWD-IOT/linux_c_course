/*********************************************************************************
 *      Copyright:  (C) 2023 red<2778465752@qq.com>
 *                  All rights reserved.
 *
 *       Filename:  rw.c
 *    Description:  This file 
 *                 
 *        Version:  1.0.0(06/19/2023)
 *         Author:  red <2778465752@qq.com>
 *      ChangeLog:  1, Release initial version on "06/19/2023 03:46:59 PM"
 *                 
 ********************************************************************************/

#include <stdio.h>

int main() {
	char filename[] = "name.txt";
	FILE *fp;
	char ch;

	// 打开文件并检查是否成功打开
	fp = fopen(filename, "w");
	if (fp == NULL) {
		printf("无法打开文件。\n");
		return 1;
	}

	// 打开/etc/passwd文件并将其内容写入文件
	FILE *passwd_fp = fopen("/etc/passwd", "r");
	while ((ch = fgetc(passwd_fp)) != EOF) {
		fputc(ch, fp);
	}

	fclose(passwd_fp);
	fclose(fp);

	printf("已成功将/etc/passwd文件的内容写入%s文件。\n", filename);
	return 0;
}




